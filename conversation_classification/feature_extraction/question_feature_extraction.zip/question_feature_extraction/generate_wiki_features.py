from sklearn.externals import joblib
from sklearn.preprocessing import Normalizer
import spacy
from spacy.en import English
from spacy.tokens.doc import Doc
import json
import numpy as np

print('Loading Clusters')
questionTypology = joblib.load('questionTypology.pkl')
motifsExtractor = joblib.load('motifsExtractor.pkl')

def _compute_question_matrix(question_text):
        '''
            Helper function to classify_question. Computes and returns a representation of
            question_text as a matrix in the latent space
        '''
        #create spacy object
        spacy_NLP = spacy.load('en')
        vocab = English().vocab
        try:
            spacy_q_obj = Doc(vocab).from_bytes(spacy_NLP(question_text).to_bytes())
        except: 
            return np.zeros((questionTypology.num_motifs, 1))


        #extract question fragments
        for span_idx, span in enumerate(spacy_q_obj.sents):
            curr_arcset = motifsExtractor.get_arcs(span.root, True)
            fragments = list(curr_arcset)

        # create question_matrix
        question_matrix = np.zeros((questionTypology.num_motifs, 1))
        for i in range(len(questionTypology.mtx_obj['q_terms'])):
            intersection = [term in fragments for term in questionTypology.mtx_obj['q_terms'][i]]
            if all(intersection):
                question_matrix[i] = 1
        question_matrix = Normalizer(norm=questionTypology.norm).fit_transform(question_matrix)
        return question_matrix

def classify_question(question_text):
        '''
            Returns the type of question_text
        '''
        question_matrix = _compute_question_matrix(question_text)
        mtx = np.matmul(question_matrix.T, questionTypology.lq)
        label = questionTypology.km.predict(mtx)
        return question_matrix, mtx, label

print('Generating Features')
wiki_features = {}

with open('questions.json') as questions:
    questions_data = json.load(questions)

for i in range(len(questions_data)):
    idx = '%s-%s-%s-%s' % (questions_data[i]['constraint'], 
        questions_data[i]['conversation_id'], questions_data[i]['action_id'], 
        questions_data[i]['sentence index'])
    question_text = questions_data[i]['content']
    question_matrix, mtx, label = classify_question(question_text)
    if sum(question_matrix) == 0:
        continue
    avg_of_motifs_vector = mtx/sum(question_matrix)
    cluster_dist_vector = questionTypology.km.transform(avg_of_motifs_vector)
    wiki_features[idx] = {
        'avg_of_motifs_vector': list(avg_of_motifs_vector[0]),
        'cluster_dist_vector': list(cluster_dist_vector[0])
    }
    print(str(i)+'/29634 Questions Done')

with open('wiki_features.json', 'w') as outfile:
    json.dump(wiki_features, outfile)
