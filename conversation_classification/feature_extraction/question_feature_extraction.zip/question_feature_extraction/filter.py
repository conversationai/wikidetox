import json

with open('question_features.json') as f:
     out = json.load(f)
keys = []
with open('input.json') as f:
     inp = json.load(f)
for i in inp:
    keys.append('%s-%s-%s-%d'%(i['constraint'], i['conversation_id'], i['action_id'], i['sentence index']))
filtered = {}
for key, val in out.items():
    if key in keys:
       filtered[key] = val
with open('question_features_filtered.json', 'w') as f:
    json.dump(filtered, f)
           
         


